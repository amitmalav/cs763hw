Completed work:
linear layer
ReLU layer
Multiple layer & framework
Criterion
Model and criterion check

Note: did not train the model